import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("http://localhost:8081/register")
selenium.click("xpath=//div[@id='root']/div/div/div/div[2]/div/div/div/div/div[2]/div[5]/div[2]/div")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/input")
selenium.type("xpath=//input[@value='Barbara Sato']", ("Barbara Sato").toString())
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[2]/input")
selenium.type("xpath=//input[@value='barbarasato@gmail.com']", ("barbarasato@gmail.com").toString())
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[3]/input")
selenium.type("xpath=//input[@value='12345']", "12345")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[4]/input")
selenium.type("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[4]/input", "12345")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[5]/div[2]")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[6]")
selenium.open("http://localhost:8081/login")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/input")
selenium.type("xpath=//input[@value='barbarasato@gmail.com']", ("barbarasato@gmail.com").toString())
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/input")
selenium.type("xpath=//input[@value='12345']", "12345")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div[2]/div/div/div/div/div[2]/div[4]")
selenium.open("http://localhost:8081/attendance")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='In�cio'])[1]/following::*[name()='svg'][2]")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div[2]/div")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div[3]/div")
selenium.open("http://localhost:8081/profile")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Presen�as'])[3]/following::*[name()='svg'][4]")
selenium.open("http://localhost:8081/support")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div[2]/div[2]/div[5]/a/div[2]")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div/div[4]/div/div/div/div[2]/div[2]/div")
selenium.open("https://www.unifecaf.com.br/contato")
selenium.selectWindow("win_ser_1")
selenium.selectWindow("win_ser_local")
selenium.open("http://localhost:8081/profile")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div[2]/div[2]/div[4]/a/div[2]")
selenium.open("http://localhost:8081/camera")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div[2]/div[2]/div[3]/a/div/div[2]")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div/div[3]/div/div/div/div/div[3]/div")
selenium.open("http://localhost:8081/profile")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Presen�as'])[3]/following::*[name()='svg'][4]")
selenium.open("http://localhost:8081/login")
selenium.click("xpath=//div[@id='root']/div/div/div[2]/div/div/div/div/div[4]/div/div/div/div[2]/div/div[4]/div")
