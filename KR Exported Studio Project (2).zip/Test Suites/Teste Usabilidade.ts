<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Teste Usabilidade</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>958e2461-44be-49a2-accf-4e0d196c0b7c</testSuiteGuid>
   <testCaseLink>
      <guid>facd7667-7aa4-4770-ab21-ea1408687e40</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Teste Usabilidade/ClassFace</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    