<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Teste ClassFace usabilidade</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>cacefb90-06ce-46b9-9d3c-713c9502fc8c</testSuiteGuid>
   <testCaseLink>
      <guid>a1f480de-1c67-4818-88b0-830f5f869be4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Teste ClassFace usabilidade/Teste de usabilidade classface</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    